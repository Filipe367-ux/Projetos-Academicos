----------------------------------------------------------------
-- PROJETO FINAL: SISTEMA DE GESTAO DE ACADEMIA (GymSystem)
-- BANCO DE DADOS II
----------------------------------------------------------------

-- 1. CRIAÇÃO DO BANCO E SCHEMA

-- CREATE DATABASE db_gymsystem;

-- Criação do Schema (A "pasta" que organiza as tabelas)
CREATE SCHEMA IF NOT EXISTS academia;

-- Definindo que este script vai rodar preferencialmente neste schema
SET search_path TO academia, public;

-- Limpeza (Para testes)
DROP TABLE IF EXISTS academia.tb05_pagamento CASCADE;
DROP TABLE IF EXISTS academia.tb04_matricula CASCADE;
DROP TABLE IF EXISTS academia.tb02_instrutor CASCADE;
DROP TABLE IF EXISTS academia.tb03_aluno CASCADE;
DROP TABLE IF EXISTS academia.tb01_plano CASCADE;

-- 2. CRIAÇÃO DAS TABELAS (DDL)

-- Tabela 01: Planos (Não depende de ninguém)
CREATE TABLE academia.tb01_plano (
    id_plano SERIAL PRIMARY KEY,
    nome_plano VARCHAR(50) NOT NULL,
    valor_mensal NUMERIC(10,2) NOT NULL CHECK (valor_mensal > 0),
    duracao_meses INT NOT NULL,
    descricao VARCHAR(100)
);

-- Tabela 02: Instrutores (Não depende de ninguém)
CREATE TABLE academia.tb02_instrutor (
    id_instrutor SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    cref VARCHAR(20) UNIQUE NOT NULL, 
    salario NUMERIC(10,2) NOT NULL
);

-- Tabela 03: Alunos (Não depende de ninguém)
CREATE TABLE academia.tb03_aluno (
    id_aluno SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    data_nascimento DATE NOT NULL,
    data_cadastro DATE DEFAULT CURRENT_DATE
);

-- Tabela 04: Matrículas (Depende de Aluno, Plano e Instrutor)
CREATE TABLE academia.tb04_matricula (
    id_matricula SERIAL PRIMARY KEY,
    id_aluno INT NOT NULL REFERENCES academia.tb03_aluno(id_aluno),
    id_plano INT NOT NULL REFERENCES academia.tb01_plano(id_plano),
    id_instrutor INT NOT NULL REFERENCES academia.tb02_instrutor(id_instrutor),
    data_inicio DATE NOT NULL DEFAULT CURRENT_DATE,
    data_fim DATE NOT NULL,
    status VARCHAR(20) CHECK (status IN ('ATIVO', 'VENCIDO', 'CANCELADO')) DEFAULT 'ATIVO'
);

-- Tabela 05: Pagamentos (Depende de Matrícula)
CREATE TABLE academia.tb05_pagamento (
    id_pagamento SERIAL PRIMARY KEY,
    id_matricula INT NOT NULL REFERENCES academia.tb04_matricula(id_matricula),
    data_pagamento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valor_pago NUMERIC(10,2) NOT NULL
);

-- 3. POPULAÇÃO DE DADOS (DML)

INSERT INTO academia.tb01_plano (nome_plano, valor_mensal, duracao_meses, descricao) VALUES
('Mensal Basic', 89.90, 1, 'Acesso musculação'),
('Trimestral Fit', 79.90, 3, 'Musculação + Aulas'),
('Semestral Pro', 69.90, 6, 'Acesso total + Avaliação'),
('Anual Gold', 59.90, 12, 'Acesso total + Convidados'),
('Plano Personal', 150.00, 1, 'Acompanhamento exclusivo');

INSERT INTO academia.tb02_instrutor (nome, cpf, cref, salario) VALUES
('Carlos Silva', '111.111.111-11', 'CREF-001/SP', 2500.00),
('Fernanda Souza', '222.222.222-22', 'CREF-002/SP', 2600.00),
('Roberto Lima', '333.333.333-33', 'CREF-003/SP', 2400.00),
('Juliana Mendes', '444.444.444-44', 'CREF-004/SP', 2800.00),
('Pedro Rocha', '555.555.555-55', 'CREF-005/SP', 2500.00);

INSERT INTO academia.tb03_aluno (nome, cpf, email, data_nascimento) VALUES
('Lucas Pereira', '999.888.777-66', 'lucas@email.com', '1995-05-10'),
('Mariana Costa', '888.777.666-55', 'mariana@email.com', '1998-11-20'),
('Rafael Santos', '777.666.555-44', 'rafael@email.com', '2000-01-15'),
('Beatriz Oliveira', '666.555.444-33', 'bia@email.com', '1992-07-30'),
('Gustavo Almeida', '555.444.333-22', 'gustavo@email.com', '1985-03-25');

INSERT INTO academia.tb04_matricula (id_aluno, id_plano, id_instrutor, data_inicio, data_fim, status) VALUES
(1, 2, 1, '2025-10-01', '2026-01-01', 'ATIVO'), 
(2, 1, 2, '2025-11-01', '2025-12-01', 'VENCIDO'),
(3, 4, 1, '2025-06-01', '2026-06-01', 'ATIVO'),
(4, 3, 3, '2025-09-01', '2026-03-01', 'ATIVO'),
(5, 1, 4, '2025-11-15', '2025-12-15', 'ATIVO');

INSERT INTO academia.tb05_pagamento (id_matricula, valor_pago) VALUES
(1, 239.70), (2, 89.90), (3, 718.80), (4, 419.40), (5, 89.90);


-- 4. PROGRAMAÇÃO DO BANCO (PL/pgSQL)

----------------------------------------------------------------
-- A. FUNÇÃO (FUNCTION)
-- Nota: Criamos a função DENTRO do schema academia
----------------------------------------------------------------
CREATE OR REPLACE FUNCTION academia.fn_verificar_acesso_aluno(p_id_aluno INT)
RETURNS VARCHAR AS $$
DECLARE
    v_status VARCHAR;
    v_data_fim DATE;
BEGIN
    -- Busca na tabela qualificada pelo schema
    SELECT status, data_fim INTO v_status, v_data_fim
    FROM academia.tb04_matricula
    WHERE id_aluno = p_id_aluno
    ORDER BY id_matricula DESC LIMIT 1;

    IF v_status = 'ATIVO' AND v_data_fim >= CURRENT_DATE THEN
        RETURN 'ACESSO LIBERADO';
    ELSE
        RETURN 'ACESSO NEGADO: Verifique sua matrícula';
    END IF;
END;
$$ LANGUAGE plpgsql;

----------------------------------------------------------------
-- B. PROCEDIMENTO (PROCEDURE)
----------------------------------------------------------------
CREATE OR REPLACE PROCEDURE academia.sp_renovar_plano(
    p_id_matricula INT,
    p_meses_adicionais INT,
    p_valor_pagamento NUMERIC
)
LANGUAGE plpgsql AS $$
BEGIN
    -- 1. Insere na tabela tb05_pagamento
    INSERT INTO academia.tb05_pagamento (id_matricula, valor_pago)
    VALUES (p_id_matricula, p_valor_pagamento);

    -- 2. Atualiza a tabela tb04_matricula
    UPDATE academia.tb04_matricula
    SET data_fim = data_fim + (p_meses_adicionais || ' months')::INTERVAL,
        status = 'ATIVO'
    WHERE id_matricula = p_id_matricula;

    RAISE NOTICE 'Renovação realizada com sucesso!';
END;
$$;

----------------------------------------------------------------
-- C. GATILHO (TRIGGER)
----------------------------------------------------------------
CREATE OR REPLACE FUNCTION academia.fn_trg_validar_aumento()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.valor_mensal > (OLD.valor_mensal * 1.5) THEN
        RAISE EXCEPTION 'Aumento abusivo! O reajuste não pode ultrapassar 50%%.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_validar_aumento_plano
BEFORE UPDATE ON academia.tb01_plano
FOR EACH ROW
EXECUTE FUNCTION academia.fn_trg_validar_aumento();


-- 5. SEGURANÇA (ROLES)

----------------------------------------------------------------
-- 5.0. LIMPEZA DE PERMISSÕES ANTIGAS (Evita erro ao re-executar)
----------------------------------------------------------------
DO $$ 
BEGIN
    -- Limpeza do ADMIN_GRUPO
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'admin_grupo') THEN
        EXECUTE 'DROP OWNED BY admin_grupo CASCADE';
        EXECUTE 'DROP ROLE admin_grupo';
    END IF;

    -- Limpeza do PROFESSOR
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'professor') THEN
        EXECUTE 'DROP OWNED BY professor CASCADE';
        EXECUTE 'DROP ROLE professor';
    END IF;

    -- Limpeza dos INTEGRANTES (Caso tenham sobrado)
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'miguel_miranda') THEN EXECUTE 'DROP ROLE miguel_miranda'; END IF;
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'luan_gali') THEN EXECUTE 'DROP ROLE luan_gali'; END IF;
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'filipe_costa') THEN EXECUTE 'DROP ROLE filipe_costa'; END IF;
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'heitor_martins') THEN EXECUTE 'DROP ROLE heitor_martins'; END IF;
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'ali_brito') THEN EXECUTE 'DROP ROLE ali_brito'; END IF;
END $$;


----------------------------------------------------------------
-- 5.1. ROLE DO GRUPO (PERFIL ADMINISTRADOR)
----------------------------------------------------------------
CREATE ROLE admin_grupo WITH NOLOGIN CREATEDB; 

GRANT ALL ON SCHEMA academia TO admin_grupo;
GRANT ALL ON ALL TABLES IN SCHEMA academia TO admin_grupo;
GRANT ALL ON ALL SEQUENCES IN SCHEMA academia TO admin_grupo;
GRANT ALL ON ALL FUNCTIONS IN SCHEMA academia TO admin_grupo;
GRANT ALL ON ALL PROCEDURES IN SCHEMA academia TO admin_grupo;


----------------------------------------------------------------
-- 5.2. ROLES DOS MEMBROS (USUÁRIOS INDIVIDUAIS)
----------------------------------------------------------------
CREATE ROLE miguel_miranda WITH LOGIN PASSWORD 'senha123';
GRANT admin_grupo TO miguel_miranda; 

CREATE ROLE luan_gali WITH LOGIN PASSWORD 'senha123';
GRANT admin_grupo TO luan_gali; 

CREATE ROLE filipe_costa WITH LOGIN PASSWORD 'senha123';
GRANT admin_grupo TO filipe_costa; 

CREATE ROLE heitor_martins WITH LOGIN PASSWORD 'senha123';
GRANT admin_grupo TO heitor_martins; 

CREATE ROLE ali_brito WITH LOGIN PASSWORD 'senha123';
GRANT admin_grupo TO ali_brito; 


----------------------------------------------------------------
-- 5.3. ROLE DO PROFESSOR (PERFIL RESTRITO/AUDITOR)
----------------------------------------------------------------
CREATE ROLE professor WITH LOGIN PASSWORD 'prof1234';

GRANT USAGE ON SCHEMA academia TO professor;
GRANT SELECT ON ALL TABLES IN SCHEMA academia TO professor;
GRANT EXECUTE ON FUNCTION academia.fn_verificar_acesso_aluno TO professor;
GRANT EXECUTE ON PROCEDURE academia.sp_renovar_plano TO professor;
GRANT INSERT, UPDATE ON academia.tb04_matricula, academia.tb05_pagamento, academia.tb01_plano TO professor;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA academia TO professor;
REVOKE DELETE ON ALL TABLES IN SCHEMA academia FROM professor;