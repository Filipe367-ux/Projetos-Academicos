--
-- PostgreSQL database dump
--

\restrict 8RxKI2FpIcgbbgmPnng2JrqcyaotgrThoNMwAtEyc9zvtUWBpfTzynXYD1givhy

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

-- Started on 2025-12-07 19:45:55

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 6 (class 2615 OID 32903)
-- Name: academia; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA academia;


ALTER SCHEMA academia OWNER TO postgres;

--
-- TOC entry 228 (class 1255 OID 32975)
-- Name: fn_trg_validar_aumento(); Type: FUNCTION; Schema: academia; Owner: postgres
--

CREATE FUNCTION academia.fn_trg_validar_aumento() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.valor_mensal > (OLD.valor_mensal * 1.5) THEN
        RAISE EXCEPTION 'Aumento abusivo! O reajuste não pode ultrapassar 50%%.';
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION academia.fn_trg_validar_aumento() OWNER TO postgres;

--
-- TOC entry 240 (class 1255 OID 32973)
-- Name: fn_verificar_acesso_aluno(integer); Type: FUNCTION; Schema: academia; Owner: postgres
--

CREATE FUNCTION academia.fn_verificar_acesso_aluno(p_id_aluno integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_status VARCHAR;
    v_data_fim DATE;
BEGIN
    -- Busca na tabela qualificada pelo schema
    SELECT status, data_fim INTO v_status, v_data_fim
    FROM academia.tb04_matricula
    WHERE id_aluno = p_id_aluno
    ORDER BY id_matricula DESC LIMIT 1;

    IF v_status = 'ATIVO' AND v_data_fim >= CURRENT_DATE THEN
        RETURN 'ACESSO LIBERADO';
    ELSE
        RETURN 'ACESSO NEGADO: Verifique sua matrícula';
    END IF;
END;
$$;


ALTER FUNCTION academia.fn_verificar_acesso_aluno(p_id_aluno integer) OWNER TO postgres;

--
-- TOC entry 241 (class 1255 OID 32974)
-- Name: sp_renovar_plano(integer, integer, numeric); Type: PROCEDURE; Schema: academia; Owner: postgres
--

CREATE PROCEDURE academia.sp_renovar_plano(IN p_id_matricula integer, IN p_meses_adicionais integer, IN p_valor_pagamento numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- 1. Insere na tabela tb05_pagamento
    INSERT INTO academia.tb05_pagamento (id_matricula, valor_pago)
    VALUES (p_id_matricula, p_valor_pagamento);

    -- 2. Atualiza a tabela tb04_matricula
    UPDATE academia.tb04_matricula
    SET data_fim = data_fim + (p_meses_adicionais || ' months')::INTERVAL,
        status = 'ATIVO'
    WHERE id_matricula = p_id_matricula;

    RAISE NOTICE 'Renovação realizada com sucesso!';
END;
$$;


ALTER PROCEDURE academia.sp_renovar_plano(IN p_id_matricula integer, IN p_meses_adicionais integer, IN p_valor_pagamento numeric) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 33165)
-- Name: tb01_plano; Type: TABLE; Schema: academia; Owner: postgres
--

CREATE TABLE academia.tb01_plano (
    id_plano integer NOT NULL,
    nome_plano character varying(50) NOT NULL,
    valor_mensal numeric(10,2) NOT NULL,
    duracao_meses integer NOT NULL,
    descricao character varying(100),
    CONSTRAINT tb01_plano_valor_mensal_check CHECK ((valor_mensal > (0)::numeric))
);


ALTER TABLE academia.tb01_plano OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 33164)
-- Name: tb01_plano_id_plano_seq; Type: SEQUENCE; Schema: academia; Owner: postgres
--

CREATE SEQUENCE academia.tb01_plano_id_plano_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE academia.tb01_plano_id_plano_seq OWNER TO postgres;

--
-- TOC entry 4864 (class 0 OID 0)
-- Dependencies: 218
-- Name: tb01_plano_id_plano_seq; Type: SEQUENCE OWNED BY; Schema: academia; Owner: postgres
--

ALTER SEQUENCE academia.tb01_plano_id_plano_seq OWNED BY academia.tb01_plano.id_plano;


--
-- TOC entry 221 (class 1259 OID 33173)
-- Name: tb02_instrutor; Type: TABLE; Schema: academia; Owner: postgres
--

CREATE TABLE academia.tb02_instrutor (
    id_instrutor integer NOT NULL,
    nome character varying(100) NOT NULL,
    cpf character varying(14) NOT NULL,
    cref character varying(20) NOT NULL,
    salario numeric(10,2) NOT NULL
);


ALTER TABLE academia.tb02_instrutor OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 33172)
-- Name: tb02_instrutor_id_instrutor_seq; Type: SEQUENCE; Schema: academia; Owner: postgres
--

CREATE SEQUENCE academia.tb02_instrutor_id_instrutor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE academia.tb02_instrutor_id_instrutor_seq OWNER TO postgres;

--
-- TOC entry 4867 (class 0 OID 0)
-- Dependencies: 220
-- Name: tb02_instrutor_id_instrutor_seq; Type: SEQUENCE OWNED BY; Schema: academia; Owner: postgres
--

ALTER SEQUENCE academia.tb02_instrutor_id_instrutor_seq OWNED BY academia.tb02_instrutor.id_instrutor;


--
-- TOC entry 223 (class 1259 OID 33184)
-- Name: tb03_aluno; Type: TABLE; Schema: academia; Owner: postgres
--

CREATE TABLE academia.tb03_aluno (
    id_aluno integer NOT NULL,
    nome character varying(100) NOT NULL,
    cpf character varying(14) NOT NULL,
    email character varying(100) NOT NULL,
    data_nascimento date NOT NULL,
    data_cadastro date DEFAULT CURRENT_DATE
);


ALTER TABLE academia.tb03_aluno OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 33183)
-- Name: tb03_aluno_id_aluno_seq; Type: SEQUENCE; Schema: academia; Owner: postgres
--

CREATE SEQUENCE academia.tb03_aluno_id_aluno_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE academia.tb03_aluno_id_aluno_seq OWNER TO postgres;

--
-- TOC entry 4870 (class 0 OID 0)
-- Dependencies: 222
-- Name: tb03_aluno_id_aluno_seq; Type: SEQUENCE OWNED BY; Schema: academia; Owner: postgres
--

ALTER SEQUENCE academia.tb03_aluno_id_aluno_seq OWNED BY academia.tb03_aluno.id_aluno;


--
-- TOC entry 225 (class 1259 OID 33196)
-- Name: tb04_matricula; Type: TABLE; Schema: academia; Owner: postgres
--

CREATE TABLE academia.tb04_matricula (
    id_matricula integer NOT NULL,
    id_aluno integer NOT NULL,
    id_plano integer NOT NULL,
    id_instrutor integer NOT NULL,
    data_inicio date DEFAULT CURRENT_DATE NOT NULL,
    data_fim date NOT NULL,
    status character varying(20) DEFAULT 'ATIVO'::character varying,
    CONSTRAINT tb04_matricula_status_check CHECK (((status)::text = ANY ((ARRAY['ATIVO'::character varying, 'VENCIDO'::character varying, 'CANCELADO'::character varying])::text[])))
);


ALTER TABLE academia.tb04_matricula OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 33195)
-- Name: tb04_matricula_id_matricula_seq; Type: SEQUENCE; Schema: academia; Owner: postgres
--

CREATE SEQUENCE academia.tb04_matricula_id_matricula_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE academia.tb04_matricula_id_matricula_seq OWNER TO postgres;

--
-- TOC entry 4873 (class 0 OID 0)
-- Dependencies: 224
-- Name: tb04_matricula_id_matricula_seq; Type: SEQUENCE OWNED BY; Schema: academia; Owner: postgres
--

ALTER SEQUENCE academia.tb04_matricula_id_matricula_seq OWNED BY academia.tb04_matricula.id_matricula;


--
-- TOC entry 227 (class 1259 OID 33221)
-- Name: tb05_pagamento; Type: TABLE; Schema: academia; Owner: postgres
--

CREATE TABLE academia.tb05_pagamento (
    id_pagamento integer NOT NULL,
    id_matricula integer NOT NULL,
    data_pagamento timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    valor_pago numeric(10,2) NOT NULL
);


ALTER TABLE academia.tb05_pagamento OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 33220)
-- Name: tb05_pagamento_id_pagamento_seq; Type: SEQUENCE; Schema: academia; Owner: postgres
--

CREATE SEQUENCE academia.tb05_pagamento_id_pagamento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE academia.tb05_pagamento_id_pagamento_seq OWNER TO postgres;

--
-- TOC entry 4876 (class 0 OID 0)
-- Dependencies: 226
-- Name: tb05_pagamento_id_pagamento_seq; Type: SEQUENCE OWNED BY; Schema: academia; Owner: postgres
--

ALTER SEQUENCE academia.tb05_pagamento_id_pagamento_seq OWNED BY academia.tb05_pagamento.id_pagamento;


--
-- TOC entry 4665 (class 2604 OID 33168)
-- Name: tb01_plano id_plano; Type: DEFAULT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb01_plano ALTER COLUMN id_plano SET DEFAULT nextval('academia.tb01_plano_id_plano_seq'::regclass);


--
-- TOC entry 4666 (class 2604 OID 33176)
-- Name: tb02_instrutor id_instrutor; Type: DEFAULT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb02_instrutor ALTER COLUMN id_instrutor SET DEFAULT nextval('academia.tb02_instrutor_id_instrutor_seq'::regclass);


--
-- TOC entry 4667 (class 2604 OID 33187)
-- Name: tb03_aluno id_aluno; Type: DEFAULT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb03_aluno ALTER COLUMN id_aluno SET DEFAULT nextval('academia.tb03_aluno_id_aluno_seq'::regclass);


--
-- TOC entry 4669 (class 2604 OID 33199)
-- Name: tb04_matricula id_matricula; Type: DEFAULT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb04_matricula ALTER COLUMN id_matricula SET DEFAULT nextval('academia.tb04_matricula_id_matricula_seq'::regclass);


--
-- TOC entry 4672 (class 2604 OID 33224)
-- Name: tb05_pagamento id_pagamento; Type: DEFAULT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb05_pagamento ALTER COLUMN id_pagamento SET DEFAULT nextval('academia.tb05_pagamento_id_pagamento_seq'::regclass);


--
-- TOC entry 4845 (class 0 OID 33165)
-- Dependencies: 219
-- Data for Name: tb01_plano; Type: TABLE DATA; Schema: academia; Owner: postgres
--

COPY academia.tb01_plano (id_plano, nome_plano, valor_mensal, duracao_meses, descricao) FROM stdin;
1	Mensal Basic	89.90	1	Acesso musculação
2	Trimestral Fit	79.90	3	Musculação + Aulas
3	Semestral Pro	69.90	6	Acesso total + Avaliação
4	Anual Gold	59.90	12	Acesso total + Convidados
5	Plano Personal	150.00	1	Acompanhamento exclusivo
\.


--
-- TOC entry 4847 (class 0 OID 33173)
-- Dependencies: 221
-- Data for Name: tb02_instrutor; Type: TABLE DATA; Schema: academia; Owner: postgres
--

COPY academia.tb02_instrutor (id_instrutor, nome, cpf, cref, salario) FROM stdin;
1	Carlos Silva	111.111.111-11	CREF-001/SP	2500.00
2	Fernanda Souza	222.222.222-22	CREF-002/SP	2600.00
3	Roberto Lima	333.333.333-33	CREF-003/SP	2400.00
4	Juliana Mendes	444.444.444-44	CREF-004/SP	2800.00
5	Pedro Rocha	555.555.555-55	CREF-005/SP	2500.00
\.


--
-- TOC entry 4849 (class 0 OID 33184)
-- Dependencies: 223
-- Data for Name: tb03_aluno; Type: TABLE DATA; Schema: academia; Owner: postgres
--

COPY academia.tb03_aluno (id_aluno, nome, cpf, email, data_nascimento, data_cadastro) FROM stdin;
1	Lucas Pereira	999.888.777-66	lucas@email.com	1995-05-10	2025-12-07
2	Mariana Costa	888.777.666-55	mariana@email.com	1998-11-20	2025-12-07
3	Rafael Santos	777.666.555-44	rafael@email.com	2000-01-15	2025-12-07
4	Beatriz Oliveira	666.555.444-33	bia@email.com	1992-07-30	2025-12-07
5	Gustavo Almeida	555.444.333-22	gustavo@email.com	1985-03-25	2025-12-07
\.


--
-- TOC entry 4851 (class 0 OID 33196)
-- Dependencies: 225
-- Data for Name: tb04_matricula; Type: TABLE DATA; Schema: academia; Owner: postgres
--

COPY academia.tb04_matricula (id_matricula, id_aluno, id_plano, id_instrutor, data_inicio, data_fim, status) FROM stdin;
1	1	2	1	2025-10-01	2026-01-01	ATIVO
2	2	1	2	2025-11-01	2025-12-01	VENCIDO
3	3	4	1	2025-06-01	2026-06-01	ATIVO
4	4	3	3	2025-09-01	2026-03-01	ATIVO
5	5	1	4	2025-11-15	2025-12-15	ATIVO
\.


--
-- TOC entry 4853 (class 0 OID 33221)
-- Dependencies: 227
-- Data for Name: tb05_pagamento; Type: TABLE DATA; Schema: academia; Owner: postgres
--

COPY academia.tb05_pagamento (id_pagamento, id_matricula, data_pagamento, valor_pago) FROM stdin;
1	1	2025-12-07 19:42:01.841738	239.70
2	2	2025-12-07 19:42:01.841738	89.90
3	3	2025-12-07 19:42:01.841738	718.80
4	4	2025-12-07 19:42:01.841738	419.40
5	5	2025-12-07 19:42:01.841738	89.90
\.


--
-- TOC entry 4878 (class 0 OID 0)
-- Dependencies: 218
-- Name: tb01_plano_id_plano_seq; Type: SEQUENCE SET; Schema: academia; Owner: postgres
--

SELECT pg_catalog.setval('academia.tb01_plano_id_plano_seq', 5, true);


--
-- TOC entry 4879 (class 0 OID 0)
-- Dependencies: 220
-- Name: tb02_instrutor_id_instrutor_seq; Type: SEQUENCE SET; Schema: academia; Owner: postgres
--

SELECT pg_catalog.setval('academia.tb02_instrutor_id_instrutor_seq', 5, true);


--
-- TOC entry 4880 (class 0 OID 0)
-- Dependencies: 222
-- Name: tb03_aluno_id_aluno_seq; Type: SEQUENCE SET; Schema: academia; Owner: postgres
--

SELECT pg_catalog.setval('academia.tb03_aluno_id_aluno_seq', 5, true);


--
-- TOC entry 4881 (class 0 OID 0)
-- Dependencies: 224
-- Name: tb04_matricula_id_matricula_seq; Type: SEQUENCE SET; Schema: academia; Owner: postgres
--

SELECT pg_catalog.setval('academia.tb04_matricula_id_matricula_seq', 5, true);


--
-- TOC entry 4882 (class 0 OID 0)
-- Dependencies: 226
-- Name: tb05_pagamento_id_pagamento_seq; Type: SEQUENCE SET; Schema: academia; Owner: postgres
--

SELECT pg_catalog.setval('academia.tb05_pagamento_id_pagamento_seq', 5, true);


--
-- TOC entry 4677 (class 2606 OID 33171)
-- Name: tb01_plano tb01_plano_pkey; Type: CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb01_plano
    ADD CONSTRAINT tb01_plano_pkey PRIMARY KEY (id_plano);


--
-- TOC entry 4679 (class 2606 OID 33180)
-- Name: tb02_instrutor tb02_instrutor_cpf_key; Type: CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb02_instrutor
    ADD CONSTRAINT tb02_instrutor_cpf_key UNIQUE (cpf);


--
-- TOC entry 4681 (class 2606 OID 33182)
-- Name: tb02_instrutor tb02_instrutor_cref_key; Type: CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb02_instrutor
    ADD CONSTRAINT tb02_instrutor_cref_key UNIQUE (cref);


--
-- TOC entry 4683 (class 2606 OID 33178)
-- Name: tb02_instrutor tb02_instrutor_pkey; Type: CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb02_instrutor
    ADD CONSTRAINT tb02_instrutor_pkey PRIMARY KEY (id_instrutor);


--
-- TOC entry 4685 (class 2606 OID 33192)
-- Name: tb03_aluno tb03_aluno_cpf_key; Type: CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb03_aluno
    ADD CONSTRAINT tb03_aluno_cpf_key UNIQUE (cpf);


--
-- TOC entry 4687 (class 2606 OID 33194)
-- Name: tb03_aluno tb03_aluno_email_key; Type: CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb03_aluno
    ADD CONSTRAINT tb03_aluno_email_key UNIQUE (email);


--
-- TOC entry 4689 (class 2606 OID 33190)
-- Name: tb03_aluno tb03_aluno_pkey; Type: CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb03_aluno
    ADD CONSTRAINT tb03_aluno_pkey PRIMARY KEY (id_aluno);


--
-- TOC entry 4691 (class 2606 OID 33204)
-- Name: tb04_matricula tb04_matricula_pkey; Type: CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb04_matricula
    ADD CONSTRAINT tb04_matricula_pkey PRIMARY KEY (id_matricula);


--
-- TOC entry 4693 (class 2606 OID 33227)
-- Name: tb05_pagamento tb05_pagamento_pkey; Type: CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb05_pagamento
    ADD CONSTRAINT tb05_pagamento_pkey PRIMARY KEY (id_pagamento);


--
-- TOC entry 4698 (class 2620 OID 33233)
-- Name: tb01_plano trg_validar_aumento_plano; Type: TRIGGER; Schema: academia; Owner: postgres
--

CREATE TRIGGER trg_validar_aumento_plano BEFORE UPDATE ON academia.tb01_plano FOR EACH ROW EXECUTE FUNCTION academia.fn_trg_validar_aumento();


--
-- TOC entry 4694 (class 2606 OID 33205)
-- Name: tb04_matricula tb04_matricula_id_aluno_fkey; Type: FK CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb04_matricula
    ADD CONSTRAINT tb04_matricula_id_aluno_fkey FOREIGN KEY (id_aluno) REFERENCES academia.tb03_aluno(id_aluno);


--
-- TOC entry 4695 (class 2606 OID 33215)
-- Name: tb04_matricula tb04_matricula_id_instrutor_fkey; Type: FK CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb04_matricula
    ADD CONSTRAINT tb04_matricula_id_instrutor_fkey FOREIGN KEY (id_instrutor) REFERENCES academia.tb02_instrutor(id_instrutor);


--
-- TOC entry 4696 (class 2606 OID 33210)
-- Name: tb04_matricula tb04_matricula_id_plano_fkey; Type: FK CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb04_matricula
    ADD CONSTRAINT tb04_matricula_id_plano_fkey FOREIGN KEY (id_plano) REFERENCES academia.tb01_plano(id_plano);


--
-- TOC entry 4697 (class 2606 OID 33228)
-- Name: tb05_pagamento tb05_pagamento_id_matricula_fkey; Type: FK CONSTRAINT; Schema: academia; Owner: postgres
--

ALTER TABLE ONLY academia.tb05_pagamento
    ADD CONSTRAINT tb05_pagamento_id_matricula_fkey FOREIGN KEY (id_matricula) REFERENCES academia.tb04_matricula(id_matricula);


--
-- TOC entry 4859 (class 0 OID 0)
-- Dependencies: 6
-- Name: SCHEMA academia; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA academia TO admin_grupo;
GRANT USAGE ON SCHEMA academia TO professor;


--
-- TOC entry 4860 (class 0 OID 0)
-- Dependencies: 228
-- Name: FUNCTION fn_trg_validar_aumento(); Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON FUNCTION academia.fn_trg_validar_aumento() TO admin_grupo;


--
-- TOC entry 4861 (class 0 OID 0)
-- Dependencies: 240
-- Name: FUNCTION fn_verificar_acesso_aluno(p_id_aluno integer); Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON FUNCTION academia.fn_verificar_acesso_aluno(p_id_aluno integer) TO admin_grupo;
GRANT ALL ON FUNCTION academia.fn_verificar_acesso_aluno(p_id_aluno integer) TO professor;


--
-- TOC entry 4862 (class 0 OID 0)
-- Dependencies: 241
-- Name: PROCEDURE sp_renovar_plano(IN p_id_matricula integer, IN p_meses_adicionais integer, IN p_valor_pagamento numeric); Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON PROCEDURE academia.sp_renovar_plano(IN p_id_matricula integer, IN p_meses_adicionais integer, IN p_valor_pagamento numeric) TO admin_grupo;
GRANT ALL ON PROCEDURE academia.sp_renovar_plano(IN p_id_matricula integer, IN p_meses_adicionais integer, IN p_valor_pagamento numeric) TO professor;


--
-- TOC entry 4863 (class 0 OID 0)
-- Dependencies: 219
-- Name: TABLE tb01_plano; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON TABLE academia.tb01_plano TO admin_grupo;
GRANT SELECT,INSERT,UPDATE ON TABLE academia.tb01_plano TO professor;


--
-- TOC entry 4865 (class 0 OID 0)
-- Dependencies: 218
-- Name: SEQUENCE tb01_plano_id_plano_seq; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON SEQUENCE academia.tb01_plano_id_plano_seq TO admin_grupo;
GRANT SELECT,USAGE ON SEQUENCE academia.tb01_plano_id_plano_seq TO professor;


--
-- TOC entry 4866 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE tb02_instrutor; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON TABLE academia.tb02_instrutor TO admin_grupo;
GRANT SELECT ON TABLE academia.tb02_instrutor TO professor;


--
-- TOC entry 4868 (class 0 OID 0)
-- Dependencies: 220
-- Name: SEQUENCE tb02_instrutor_id_instrutor_seq; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON SEQUENCE academia.tb02_instrutor_id_instrutor_seq TO admin_grupo;
GRANT SELECT,USAGE ON SEQUENCE academia.tb02_instrutor_id_instrutor_seq TO professor;


--
-- TOC entry 4869 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE tb03_aluno; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON TABLE academia.tb03_aluno TO admin_grupo;
GRANT SELECT ON TABLE academia.tb03_aluno TO professor;


--
-- TOC entry 4871 (class 0 OID 0)
-- Dependencies: 222
-- Name: SEQUENCE tb03_aluno_id_aluno_seq; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON SEQUENCE academia.tb03_aluno_id_aluno_seq TO admin_grupo;
GRANT SELECT,USAGE ON SEQUENCE academia.tb03_aluno_id_aluno_seq TO professor;


--
-- TOC entry 4872 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE tb04_matricula; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON TABLE academia.tb04_matricula TO admin_grupo;
GRANT SELECT,INSERT,UPDATE ON TABLE academia.tb04_matricula TO professor;


--
-- TOC entry 4874 (class 0 OID 0)
-- Dependencies: 224
-- Name: SEQUENCE tb04_matricula_id_matricula_seq; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON SEQUENCE academia.tb04_matricula_id_matricula_seq TO admin_grupo;
GRANT SELECT,USAGE ON SEQUENCE academia.tb04_matricula_id_matricula_seq TO professor;


--
-- TOC entry 4875 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE tb05_pagamento; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON TABLE academia.tb05_pagamento TO admin_grupo;
GRANT SELECT,INSERT,UPDATE ON TABLE academia.tb05_pagamento TO professor;


--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 226
-- Name: SEQUENCE tb05_pagamento_id_pagamento_seq; Type: ACL; Schema: academia; Owner: postgres
--

GRANT ALL ON SEQUENCE academia.tb05_pagamento_id_pagamento_seq TO admin_grupo;
GRANT SELECT,USAGE ON SEQUENCE academia.tb05_pagamento_id_pagamento_seq TO professor;


-- Completed on 2025-12-07 19:45:56

--
-- PostgreSQL database dump complete
--

\unrestrict 8RxKI2FpIcgbbgmPnng2JrqcyaotgrThoNMwAtEyc9zvtUWBpfTzynXYD1givhy

